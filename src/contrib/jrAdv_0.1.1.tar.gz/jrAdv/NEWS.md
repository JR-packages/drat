# jrAdv 0.1.1 _2020-12-07_

  * Update: Package title must match course
  * Add NEWS.md
  * Fix lintr errors
