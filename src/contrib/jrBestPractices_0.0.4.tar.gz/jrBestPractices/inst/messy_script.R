# Lasted edited by Maria Garcia on 23rd March 2020
# import some data
data(mtcars, package ="datasets")
summariseCars =function(x){
  library('dplyr')
  summarise.mpg(
  x %>%
         group_by(carb))
}
plot.title <- 'MPG by number of carburettors' # This is where I define the plot title
library("tidyr")
# compute mean mpg by carb
summarise.mpg = function(x) { summarise(x, mpg_mean = mean(  mpg), mpg_sd = sd(mpg ))} # This function summarises the mpg variable
company_colour = "#516e7a" # Branding added by Jason on 2020/04/01
summariseCars(mtcars)
# plot all mpg values, partitioned by carb
library("ggplot2") # Use ggplot2 package
mtcars %>%
 ggplot(aes(x = factor(carb),y=mpg), ) +
        geom_boxplot(fill=company_colour)  + # Makes a boxplot coloured by company colour
ggtitle(plot.title) # This adds a title to the plot
# theme_dark() # Add dark theme
