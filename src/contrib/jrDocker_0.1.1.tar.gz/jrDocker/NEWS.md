# jrDocker 0.1.1 _2020-12-07_
   * Add NEWS.md
   * Change pkg title
