# jrDocker 0.1.2 _2021-02-09_
   * Change pkg title
   
# jrDocker 0.1.1 _2020-12-07_
   * Add NEWS.md
   * Change pkg title
