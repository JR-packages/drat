# jrDocker
[![Build Status](https://api.travis-ci.org/jr-packages/jrDocker.png?branch=master)](https://travis-ci.org/jr-packages/jrDocker)

Dummy package for testing infrastructure.
