#' Efficient R programming
#'
#' Functions and datasets used by Jumping Rivers.
#' @name jrEfficient-package
#' @aliases jrEfficient
#' @docType package
NULL
