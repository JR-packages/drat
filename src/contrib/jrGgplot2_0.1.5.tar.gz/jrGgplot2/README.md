# Advanced R Graphics
[![Build Status](https://api.travis-ci.org/jr-packages/jrGgplot2.svg?branch=master)](https://travis-ci.org/jr-packages/jrGgplot2)

Course material for the [Advanced graphics](https://jumpingrivers.com) course. 
