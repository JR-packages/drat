## ----include = FALSE----------------------------------------------------------
library(tufte)
# knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- warning = FALSE, message = FALSE----------------------------------------
library(dplyr)
data("yeast", package = "jrIntroBio")

## -----------------------------------------------------------------------------
head(yeast)
colnames(yeast)

## -----------------------------------------------------------------------------
exc = filter(yeast, class == "EXC")

## -----------------------------------------------------------------------------
summarise(exc, mean(mcg))
# or
# mean(exc$mcg)

## -----------------------------------------------------------------------------
count(yeast, class)
## more nuclear

## -----------------------------------------------------------------------------
yeast %>%
  filter(gvh < 0.2) %>%
  nrow()

## ----echo=TRUE, eval=FALSE----------------------------------------------------
#  yeast %>%
#    summarise(mean = mean(mit))

## ---- eval=FALSE--------------------------------------------------------------
#  yeast %>%
#    group_by(class) %>%
#    summarise(mean = mean(mit))

## ---- eval=FALSE--------------------------------------------------------------
#  yeast %>%
#    group_by(class) %>%
#    summarise(n = n(),
#              mean = mean(mit),
#              sd = sd(mit))

## ---- eval=FALSE--------------------------------------------------------------
#  yeast %>%
#    select(-seq) %>%
#    group_by(class) %>%
#    summarise_all(mean)

