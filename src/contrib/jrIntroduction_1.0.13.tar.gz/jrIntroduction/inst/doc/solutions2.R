## ----include = FALSE----------------------------------------------------------
library(tufte)

## ---- echo = TRUE, message = FALSE--------------------------------------------
data(movies, package = "jrIntroduction")

## ---- eval = FALSE------------------------------------------------------------
#  head(movies)

## -----------------------------------------------------------------------------
dim(movies)

## -----------------------------------------------------------------------------
mean(movies$duration)
median(movies$duration)

## -----------------------------------------------------------------------------
min(movies$year)

## -----------------------------------------------------------------------------
max(movies$duration)

## -----------------------------------------------------------------------------
sd(movies$rating)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  table(movies$action)

## ---- eval = FALSE------------------------------------------------------------
#  # Counting up the categories within a vector

## ---- eval = FALSE, echo = TRUE-----------------------------------------------
#  library("jrIntroduction")
#  get_csv_movies_file()

## ----echo =FALSE, results = "markup", out.width='0.6\\textwidth'--------------
fname = system.file("import_data.png", package = "jrIntroduction")
knitr::include_graphics(fname)

## ---- eval= FALSE, echo = TRUE------------------------------------------------
#  vignette("solutions2", package = "jrIntroduction")

