# jrIntroduction 1.1.0 _2021-06-28_
  * Tidy DESCRIPTION file

# jrIntroduction 1.0.* _2021-04-14_

  * Add haven to demo reading SAS files
  * Initialise
