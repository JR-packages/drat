#' @import coin
#' @import titanic
NULL
