#' Statistical Modelling by Jumping Rivers
#'
#' Functions and datasets used in external R courses
#' @name jrModelling-package
#' @aliases jrModelling
#' @docType package
#' @keywords package
NULL
