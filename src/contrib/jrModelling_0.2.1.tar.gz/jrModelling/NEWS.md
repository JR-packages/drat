# jrModelling 0.2.1 _2020-10-26_

  * Update: Package title must match course
