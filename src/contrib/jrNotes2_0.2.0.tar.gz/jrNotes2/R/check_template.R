has_changed = function(i, fnames, templates) {
  fname1 = fnames[i]; template_file = templates[i]
  if (!file.exists(fname1) && !is_gitlab()) {
    fs::file_copy(template_file, fname1)
    msg_info(glue("Updating {fname1}"), padding = TRUE)
    return(invisible(TRUE))
  }

  d1 = digest::digest(readLines(fname1))
  d2 = digest::digest(readLines(template_file))
  if (d1 != d2) {
    if (!is_gitlab()) {
      msg_info(glue("Updating {fname1}"), padding = TRUE)
      fs::file_copy(template_file, fname1, overwrite = TRUE)
    }
    return(invisible(TRUE))
  }
  msg_success(fname1, padding = TRUE)
  return(invisible(FALSE))
}

check_notes_references = function() {
  root_dir = get_root_dir()
  refs_path = file.path(root_dir, "notes", "references.bib")
  if (file.exists(refs_path)) {
    msg_success("notes/references.bib", padding = TRUE)
  } else if (file.exists(file.path(root_dir, "notes"))) {
    msg_info("notes/references.bib is missing", padding = TRUE)
    dir = system.file("template", package = "jrNotes2")
    fs::file_copy(file.path(dir, "notes/references.bib"), refs_path)
    msg_success("Updating references.bib", padding = TRUE)
  }
  return(invisible(NULL))
}

check_template_ci = function() {
  root_dir = get_root_dir()
  ci_file = file.path(root_dir, ".template-gitlab-ci.yml")
  if (!file.exists(ci_file)) return(invisible(NULL))

  msg_warning("You are using the old style CI. Please delete .template-gitlab-ci.yml")
  msg_warning("Then replace the include line in the .gitlab-ci.yml file with")
  cat("\n\ninclude:\n")
  cat("  - project: 'jumpingrivers-notes/r/jrnotes2'\n")
  cat("    ref: master\n")
  cat("    file: 'ci/template-gitlab-ci.yml'\n\n")
  return(invisible(NULL))
}

check_root_dir = function() {
  # TODO: Add check template ci function call
  root_dir = get_root_dir()
  proj_name = get_project_name()
  files = c("Makefile", ".gitignore",
            glue::glue("{proj_name}.Rproj"))
  root_files = file.path(root_dir, files)
  dir = system.file("template", package = "jrNotes2")

  ## R pkgs auto remove .gitignores - so need to remove .
  files = c("Makefile", "gitignore", "notes/notes_template.Rproj")
  template_fnames = file.path(dir, files)
  changed = vapply(seq_along(root_files), has_changed,
                   root_files, template_fnames, FUN.VALUE = logical(1))
  changed = any(changed)

  if (length(list.files(pattern = "*\\.Rproj$", path = root_dir)) > 1L) {
    msg_error("Don't add multiple Rproj files to the base directory.")
    changed = TRUE
  }
  return(changed)
}

check_notes_dir = function() {
  root_dir = get_root_dir()
  notes_dir = file.path(root_dir, "notes")
  if (!file.exists(notes_dir)) return(invisible(NULL))
  proj_name = get_project_name()
  files = c(glue::glue("notes_{proj_name}.Rproj"), "Makefile", "main.Rmd")
  root_files = file.path(notes_dir, files)

  ## Template files
  dir = system.file("template/notes", package = "jrNotes2")
  template_fnames = file.path(dir, c("notes_template.Rproj", "Makefile", "main.Rmd"))
  changed = vapply(seq_along(root_files), has_changed,
                   root_files, template_fnames, FUN.VALUE = logical(1))
  changed = any(changed)

  check_notes_references()
  if (length(list.files(pattern = "*\\.Rproj$", path = notes_dir)) != 1L) {
    msg_error("There should only be a single Rproj file in notes/")
    changed = TRUE
  }
  return(changed)
}

check_slides_dir = function() {
  root_dir = get_root_dir()
  slides_dir = file.path(root_dir, "slides")
  if (!file.exists(slides_dir)) return(invisible(NULL))
  proj_name = get_project_name()
  files = c(glue::glue("slides_{proj_name}.Rproj"), "Makefile")
  ## Template files
  root_files = file.path(slides_dir, files)
  dir = system.file("template/slides", package = "jrNotes2")
  template_fnames = file.path(dir, c("slides_template.Rproj", "Makefile"))

  ## Compare files
  changed = vapply(seq_along(root_files), has_changed,
                   root_files, template_fnames, FUN.VALUE = logical(1))
  changed = any(changed)

  if (length(list.files(pattern = "*\\.Rproj$", path = slides_dir)) != 1L) {
    msg_error("There should only be a single Rproj file in notes/")
    changed = TRUE
  }
  return(changed)
}

#' Checks notes files are the same as template
#'
#' Ensures that certain notes files are the same as the notes template.
#' These canonical files are identical for all notes, e.g. Makefiles,
#' main.Rmd.
#'
#' Typically this used by the gitlab-ci runner. The programming
#' language is inferred via \code{get_repo_language}.
#' @export
check_template = function() {
  msg_start("Checking template files...check_template()")
  if (Sys.getenv("CI_PROJECT_NAME") == "jrNotes2") {
    # Feedback loop if we test template on it's on master
    msg_info("On GitLab - skipping check")
    return(invisible(NULL))
  }

  changed = all(check_root_dir() &  check_notes_dir() & check_slides_dir())
  if (changed  &&
      nchar(Sys.getenv("GITLAB_CI")) != 0) {
    msg = glue::glue("Files differs from template. \\
          Either revert your changes or update the template. \\
          If you think you want to update the template, make a merge \\
          request and ask for feedback.")
    msg_error(msg)
  }
  if (isFALSE(changed)) msg_success("Template files look good")
  return(invisible(NULL))
}
