# jrNotes2 1.0.3 _2021-01-10_
  * Feature: Install local python packages on local machines
  * Feature: Language is no longer used by venv. Instead, just look at config for python dep

# jrNotes2 1.0.2 _2021-01-08_
  * Bug: Local Python packages requires full path to install

# jrNotes2 1.0.1 _2021-01-08_
  * Feature: Install local packages

# jrNotes2 1.0.0 _2021-01-05_
  * Internal: Simplify extracting logical values from config
  * Bug: detect lintr in config file

# jrNotes2 0.11.1 _2020-12-14_
  * Internal: Allow `provision_venv()` to create `virtualenv` in places other
    than just the `notes/` directory
   
