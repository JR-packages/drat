# jrNotes2 
<!-- badges: start -->
[![Build Status](https://api.travis-ci.org/jr-packages/jrNotes2.png?branch=master)](https://travis-ci.org/jr-packages/)
[![Codecov test coverage](https://codecov.io/gh/jr-packages/jrNotes2/branch/master/graph/badge.svg)](https://codecov.io/gh/jr-packages/jrNotes2?branch=master)
<!-- badges: end -->
---

Package for Jumping Rivers Notes

