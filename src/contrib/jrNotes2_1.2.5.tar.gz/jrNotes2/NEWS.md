# jrNotes2 1.2.5 _2021-05-14_
  * Bug: Fix asana task fetching by adding `as_tibble=FALSE` to {jrApiAsana}
    call

# jrNotes2 1.2.4 _2021-05-13_
  * Improvement: Improved feedback during render

# jrNotes2 1.2.3 _2021-05-08_
  * Improvement: add `add_notes = TRUE` argument to `create_live_scripts()` for 
  independent make process for `live/` (particularly useful for live python)
  * Internal: Remove code duplication in `create_live_scripts()`

# jrNotes2 1.2.2 _2021-05-07_
  * Bug: Fix cleaning bug

# jrNotes2 1.2.1 _2021-05-06_
  * Internal: Fixing annoying typo. "Underfined" -> "Undefined"

# jrNotes2 1.2.0 _2021-05-05_
  * Internal: Use `latexmk -c` to clean intermediary LaTeX files (rather than
    manually listing)
  * Internal: Remove `highlight.tex` at `clean()`

# jrNotes2 1.1.* _2021-05-05_
  * Bug: Fix bug which flags alphabetisation of WORDLIST if the WORDLIST has
    any blank lines
  * Bug: Fix bug which overwrote the chunk caption hook with the noqa chunk
    hook
  * Bug: Fix bug which meant course advert and dependencies were never included
    compilation
  * Feature: Add functions to help build gdocs and multiple choice quizzes
  * Feature: Strip `\VERB` from section titles for comparison between `live/` and
    `notes/`
  * Feature: Build google-docs from Rmds
  * Feature: Add `notes_img_fname_check()` to check website featured img filenames
  * Feature: Add functionality to copy featured img's from notes to website repo
  * Feature: Remove flake8 noqa's from code chunks
  * Feature: Use latexmk in quiet mode, reducing all the noise during
  * Internal: Re-tidy description following {desc} update

# jrNotes2 1.0.* _2021-02-28_
  * Bug: The {knitr} options in config.yml were ignored
  * Feature: Improved feedback when building the notes
  * Internal: Slightly more robust path construction
  * Feature: Update website/index.md with material file names
  * Bug: Use a venv to build python vignettes
  * Feature: Move `check_template()` to standard `render()` function
  * Feature: Different render types can can now be specified. Currently only jrPyVis
  * Feature: Alter `jrStyle.sty` to work for notes _without_ any code chunks
  * Feature: `main.Rmd` now called `index.Rmd`
  * Internal: Add docker pull before docker build in Makefile template
  * Bug: Remove old python .tar.gz pkgs to avoid caching issues
  * Bug: python template location
  * Internal: Add functionality in create_materials.R
  * Internal: Add `libpoppler-cpp-dev` to `deb_pkgs` in config.yml
  * Internal: Add `create_materials()` to `create_final_dir()`
  * Feature: Check python package Makefile template
  * Feature: Makefile dependency on vignette source in python packages
  * Bug: Updated root Makefile template for notes projects
  * Feature: Install local python packages on local machines
  * Feature: Language is no longer used by venv. Instead, just look at config for python dep
  * Bug: Local Python packages requires full path to install
  * Feature: Install local packages
  * Internal: Simplify extracting logical values from config
  * Bug: detect lintr in config file
  * Internal: Allow `provision_venv()` to create `virtualenv` in places other
    than just the `notes/` directory
   
