# Update README.md using the values from config.yml
# TODO: Update gitlab project description?
update_readme = function() {
  config = get_config()
  version = config$version
  readme = glue::glue("# {config$running} (v{version})")

  if (!is.null(config$deb_pkgs)) {
    pkgs = paste("-", config$deb_pkgs, collapse = "\n")
    readme = glue::glue("{readme}
                        ### Debian Packages

                        {pkgs}")
  }

  readr::write_lines(readme, file = file.path(get_root_dir(), "README.md"))
  rmd = file.path(get_root_dir(), "README.Rmd")
  if (file.exists(rmd)) fs::file_delete(rmd)
  msg_success("Updating README.md", padding = TRUE)
  return(invisible(NULL))
}
