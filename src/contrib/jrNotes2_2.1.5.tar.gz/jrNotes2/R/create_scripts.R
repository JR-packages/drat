#' Create scripts for online training
#'
#' Creates the folders vm_scripts/ and tutor_scripts/
#'
#' For each chapter in scripts/, creates exercises.{ext},
#' exercises-backup.{ext} and exercises-solutions.{ext} from
#' main_exercises.{ext}
#'
#' For each chapter in scripts/, creates tutor_suffix.{ext} and
#' demo_suffix.{ext} from main_tutor_suffix.{ext}
#'
#' Zips vm_scripts/ and tutor_scripts/ ready for use by {jrDroplet}
#' @importFrom fs dir_exists dir_create dir_ls file_delete
#' @param scripts_path Path to the scripts directory. If NULL, uses get_root_dir()/scripts
#' @param notes_path Path to the notes directory. If NULL, uses get_root_dir()/notes
#' @param add_notes Whether to copy notes pdf into vm_scripts folder
#' @export
create_scripts = function(scripts_path = NULL, notes_path = NULL, add_notes = TRUE) {

  if (is.null(scripts_path)) scripts_path = file.path(get_root_dir(), "scripts")
  if (!fs::dir_exists(scripts_path)) return(invisible(NULL))

  msg_start("Creating scripts for VM...")

  # Create paths to vm_scripts and tutor_scripts directories
  scripts_dir = file.path(scripts_path, c("vm_scripts", "tutor_scripts"))
  # Create vm_scripts and tutor_scripts directories
  fs::dir_create(scripts_dir)
  # Clean any existing content from previous runs
  fs::file_delete(fs::dir_ls(scripts_dir))

  # List chapters
  chapters = list.files(path = scripts_path, pattern = "chapter")
  # Create chapter subdirectories
  fs::dir_create(file.path(scripts_path, "vm_scripts", chapters))
  fs::dir_create(file.path(scripts_path, "tutor_scripts", chapters))

  if (get_repo_language() == "python") {
    create_scripts_python(scripts_path, chapters)
  } else {
    create_scripts_r(scripts_path, chapters)
  }

  # Zip the vm_scripts and tutor_scripts folders
  zip_scripts(scripts_path, notes_path = notes_path, add_notes = add_notes)

  msg_success("Live scripts created and zipped")
}

#' Create scripts for python courses
#'
#' Creates exercises.ipynb, exercises-backup.ipynb, exercises-solutions.ipynb,
#' tutor_suffix.ipynb and demo_suffix.ipynb for each chapter
#'
#' @importFrom fs dir_ls file_delete
#' @param scripts_path The location to the scripts directory
#' @param chapters The path to the chapters to create
create_scripts_python = function(scripts_path, chapters) {
  for (chapter in chapters) {
    add_imgs(scripts_path, chapter)
    create_chapter_demos(scripts_path, chapter, is_python = TRUE)
    create_chapter_exercises(scripts_path, chapter, is_python = TRUE)
  }
  # Remove Rmd's from vm_scripts/ and tutor_scripts/
  scripts_dir = file.path(scripts_path, c("vm_scripts", "tutor_scripts"))
  fs::file_delete(fs::dir_ls(scripts_dir, glob = "*.Rmd$", recurse = 1))
}

#' Create scripts for r courses
#'
#' Creates exercises.(Rmd|R), exercises-backup.(Rmd|R),
#' exercises-solutions.(Rmd|R), tutor_suffix.(Rmd|R) and demo_suffix.(Rmd|R)
#' for each chapter
#'
#' @param scripts_path The path to the scripts directory
#' @param chapters The path to the chapters to create
create_scripts_r = function(scripts_path, chapters) {
  for (chapter in chapters) {
    add_imgs(scripts_path, chapter)
    create_chapter_demos(scripts_path, chapter)
    create_chapter_exercises(scripts_path, chapter)
  }
}

#' Copy images into vm_scripts/ folder
#'
#' @importFrom stringr str_subset str_replace
#' @importFrom fs file_copy
#' @param scripts_path The path to the scripts directory
#' @param chapter The path to the chapter to copy images from
add_imgs = function(scripts_path, chapter) {
  # Check for images
  files = list.files(file.path(scripts_path, chapter), full.names = TRUE)
  imgs = stringr::str_subset(files, "\\.png$")

  # Copy images
  if (length(imgs) > 0) {
    fs::file_copy(
      path = imgs,
      new_path = stringr::str_replace(imgs, scripts_path,
                                      file.path(scripts_path, "vm_scripts")),
      overwrite = TRUE
    )
  }
}

#' Create tutor_suffix.{ext} and demo_suffix.{ext} from
#' main_tutor_suffix.(Rmd|R)
#'
#' @importFrom fs dir_ls
#' @param scripts_path The path to the scripts directory
#' @param chapter The path to the chapter to copy images from
#' @param is_python Boolean determining whether to convert Rmd's to ipynb's
create_chapter_demos = function(scripts_path, chapter, is_python = FALSE) {
  # Finds eg. main_tutor.R, main_tutor_part1.Rmd, main_tutor_2.R
  # Ignores eg. main_tutor2.R, main_tutor-2.Rmd
  demo_files = fs::dir_ls(file.path(scripts_path, chapter),
                          regexp = "main_tutor(_.*)*\\.(Rmd|R)$")

  # Extract chapter number from chapter name
  chap_num = stringr::str_extract(chapter, "\\d{1,2}")

  for (i in seq_along(demo_files)) {
    # Construct filename for tutor script
    # chapterX/main_tutor.(Rmd|R) --> X-tutor.(Rmd|R)
    # chapterX/main_tutor_example.(Rmd|R) --> X-tutor_example.(Rmd|R) etc.
    tutor_filename = gsub("main_", glue::glue("{chap_num}-"),
                          basename(demo_files[i]))

    # Construct filename for demo script
    # chapterX/main_tutor.(Rmd|R) --> X-demo.(Rmd|R)
    # chapterX/main_tutor_example.(Rmd|R) --> X-demo_example.(Rmd|R) etc.
    demo_filename = gsub("main_tutor", glue::glue("{chap_num}-demo"),
                         basename(demo_files[i]))

    # Create paths to files to create
    tutor_file_path = file.path(scripts_path, "tutor_scripts",
                                chapter, tutor_filename)
    demo_file_path = file.path(scripts_path, "vm_scripts",
                               chapter, demo_filename)

    # Create tutor script:
    #   Remove lines which begin with #>
    #   Keep (and reveal) lines beginning with #<
    sed_file("/^#>.*/d ; s/^#< //", demo_files[i], tutor_file_path)
    # Create demo script:
    #   Remove lines which begin with #<
    #   Keep (and reveal) lines beginning with #>
    sed_file("/^#<.*/d ; s/^#> //", demo_files[i], demo_file_path)

    # If a python course, convert to .ipynb
    if (isTRUE(is_python)) {
      make_ipynb(tutor_file_path)
      make_ipynb(demo_file_path)
    }
  }
}

#' Create exercises.{ext}, exercises-backup.{ext} and exercises-solutions.{ext}
#' from main_exercises.(Rmd|R)
#'
#' @importFrom fs dir_ls file_copy
#' @importFrom glue glue
#' @param scripts_path The path to the scripts directory
#' @param chapter The path to the chapter to copy images from
#' @param is_python Boolean determining whether to convert Rmd's to ipynb's
create_chapter_exercises = function(scripts_path, chapter, is_python = FALSE) {
  # Get path to main_exercises.(Rmd|R)
  exercise = fs::dir_ls(file.path(scripts_path, chapter),
                        regexp = "main_exercises\\.(Rmd|R)$")
  # If there are no exercises head back
  if (length(exercise) == 0) return(invisible(NULL))

  # Get file extension of main_exercises
  ext = strsplit(exercise, "\\.")[[1]][2]

  # Extract chapter number from chapter name
  chap_num = stringr::str_extract(chapter, "\\d{1,2}")

  # Create path to exercises file
  exercises_file_path = file.path(scripts_path, "vm_scripts", chapter,
                                  glue::glue("{chap_num}-exercises.{ext}"))
  # Create exercises file
  #   Remove lines which begin with #>
  #   Keep (and reveal) lines beginning with #<
  sed_file("/^#>.*/d ; s/^#< //", exercise, exercises_file_path)

  # Create path to exercises-backup file
  backup_file_path = file.path(scripts_path, "vm_scripts", chapter,
                               glue::glue("{chap_num}-exercises-backup.{ext}"))
  # Create exercises-backup file
  fs::file_copy(
    path = exercises_file_path,
    new_path = backup_file_path,
    overwrite = TRUE
  )

  # Create path to exercises-solution file
  solutions_file_path = file.path(scripts_path, "vm_scripts", chapter,
                                  glue::glue("{chap_num}-exercises-solutions.{ext}"))
  # Create exercises-solutions file
  #   Remove lines which begin with #<
  #   Keep (and reveal) lines beginning with #>
  sed_file("/^#<.*/d ; s/^#> //", exercise, solutions_file_path)

  # If a python course, convert to .ipynb
  if (isTRUE(is_python)) {
    make_ipynb(exercises_file_path)
    make_ipynb(backup_file_path)
    make_ipynb(solutions_file_path)
  }
}

#' Apply sed transofrm to in_file and output to out_file
#'
#' @param transform Sed transform to apply to in_file
#' @param in_file Path to file to apply sed to
#' @param out_file Path to file to write output to
sed_file = function(transform, in_file, out_file) {
  system2("sed",
          args = c(shQuote(transform), in_file),
          stdout = out_file)
}

#' Convert Rmd file to ipynb
#'
#' @param in_file Path to file to convert to ipynb
make_ipynb = function(in_file) {
  system2("jupytext", args = c("--to", "notebook", in_file, "--quiet"))
}

#' Zips vm_scripts and tutor_scripts ready for {jrDroplet}
#'
#' @importFrom fs file_copy
#' @importFrom zip zipr
#' @param scripts_path The path to the scripts directory
#' @param notes_path Path to the notes directory
#' @param add_notes Whether to copy notes pdf into vm_scripts folder
zip_scripts = function(scripts_path, notes_path, add_notes) {
  # Zip folder
  msg_start("Zipping scripts...")
  scripts_dir = file.path(scripts_path, c("vm_scripts", "tutor_scripts"))

  # Copy notes into vm_scripts.zip (if desired)
  if (isTRUE(add_notes)) {
    if (is.null(notes_path)) notes_path = file.path(get_root_dir(), "notes")
    fs::file_copy(file.path(notes_path, "index.pdf"),
                  file.path(scripts_path, "vm_scripts", "notes.pdf"),
                  overwrite = TRUE)
  }

  zip::zipr(
    zipfile = file.path(scripts_path, "tutor_scripts.zip"),
    files = file.path(scripts_path, "tutor_scripts")
  )
  zip::zipr(
    zipfile = file.path(scripts_path, "vm_scripts.zip"),
    files = file.path(scripts_path, "vm_scripts")
  )
}
