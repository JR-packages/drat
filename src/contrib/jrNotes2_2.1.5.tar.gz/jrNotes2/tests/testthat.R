library("testthat")
library("jrNotes2")

test_check("jrNotes2")
