# jrNotes2 2.1.6 _2021-07-08_
  * Bug: \r in chunk output raised an error

# jrNotes2 2.1.5 _2021-06-29_
  * Refactor `create_scripts()` logic
  * Prefix outputted script files with their corresponding chapter number
  * Output learner files as `X-demo_suffix.{ext}`, and tutor files as
    `X-tutor.{ext}`
  * Allow any files matching `"main_tutor(_.*)\\.(Rmd|R)"` to be present
    in scripts
  * Make jupytext quiet

# jrNotes2 2.1.4 _2021-06-28_
  * Add slides/_site/ to .gitignore

# jrNotes2 2.1.3 _2021-06-25_
  * Course back matter shouldn't be numbered

# jrNotes2 2.1.2 _2021-06-18_
  * Ensure course dependencies image appears on its own page at the end of the
    notes

# jrNotes2 2.1.1 _2021-06-18_
  * Fix bug in which Rmd files are removed from all vm_scripts folders (the
    jrrmarkdown course's materials are all .Rmd files)

# jrNotes2 2.1.0 _2021-06-18_
  * Only remove index.pdf at make cleaner
  * Ensure make clean _only_ removes intermediaries

# jrNotes2 2.0.* _2021-06-15_
  * Check system dependencies are installed before rendering
  * Fix bug which sometimes caused `tokenise()` to hang indefinitely
  * Use full paths to extractor files to use as inputs in call to xelatex
  * Fix minor bug in `read_file_as_chunk`
  * Move {jrApiAsana} from imports to suggests for easier external
    collaboration
  * Strip `# nolint`, `# nolint start` and `# nolint end` from outputted code chunk
  * Improve `update_readme()`
  * Move `update_readme()` call to notes/Makefile
  * Adding `.swp` to .gitignore
  * Fix slides Makefile
  * Add a function to use an external file (or snippets of) as source for a
    chunk
  * Add `update_readme()` function. Still basic. 
  * Migrate notes from gitlab.com/jumpingrivers-notes to
    gitlab.com/jumpingrivers/training
  * Rename master branch to main
  * Rename `live/` as `scripts/`
  

# jrNotes2 1.2.* _2021-05-22_
  * Improvement: Render google document in a virtual environment (in the same
    manner as the pdf notes)
  * Improvement: Make code font bigger in google doc quizzes
  * Internal: Materials were constantly being changed due to the nature of pngs being 
  different. Instead, generate on the CI and change when necessary.
  * Improvement: Force inclusion of pages 1 and 3 in website materials (rather
    than page 1 and page 2: as page 2 is a JR advert anyway)
  * Bug: Fix asana task fetching by adding `as_tibble=FALSE` to {jrApiAsana}
    call
  * Improvement: Improved feedback during render
  * Improvement: add `add_notes = TRUE` argument to `create_live_scripts()` for 
  independent make process for `live/` (particularly useful for live python)
  * Internal: Remove code duplication in `create_live_scripts()`
  * Bug: Fix cleaning bug
  * Internal: Fixing annoying typo. "Underfined" -> "Undefined"
  * Internal: Use `latexmk -c` to clean intermediary LaTeX files (rather than
    manually listing)
  * Internal: Remove `highlight.tex` at `clean()`

# jrNotes2 1.1.* _2021-05-05_
  * Bug: Fix bug which flags alphabetisation of WORDLIST if the WORDLIST has
    any blank lines
  * Bug: Fix bug which overwrote the chunk caption hook with the noqa chunk
    hook
  * Bug: Fix bug which meant course advert and dependencies were never included
    compilation
  * Feature: Add functions to help build gdocs and multiple choice quizzes
  * Feature: Strip `\VERB` from section titles for comparison between `live/` and
    `notes/`
  * Feature: Build google-docs from Rmds
  * Feature: Add `notes_img_fname_check()` to check website featured img filenames
  * Feature: Add functionality to copy featured img's from notes to website repo
  * Feature: Remove flake8 noqa's from code chunks
  * Feature: Use latexmk in quiet mode, reducing all the noise during
  * Internal: Re-tidy description following {desc} update

# jrNotes2 1.0.* _2021-02-28_
  * Bug: The {knitr} options in config.yml were ignored
  * Feature: Improved feedback when building the notes
  * Internal: Slightly more robust path construction
  * Feature: Update website/index.md with material file names
  * Bug: Use a venv to build python vignettes
  * Feature: Move `check_template()` to standard `render()` function
  * Feature: Different render types can can now be specified. Currently only jrPyVis
  * Feature: Alter `jrStyle.sty` to work for notes _without_ any code chunks
  * Feature: `main.Rmd` now called `index.Rmd`
  * Internal: Add docker pull before docker build in Makefile template
  * Bug: Remove old python .tar.gz pkgs to avoid caching issues
  * Bug: python template location
  * Internal: Add functionality in create_materials.R
  * Internal: Add `libpoppler-cpp-dev` to `deb_pkgs` in config.yml
  * Internal: Add `create_materials()` to `create_final_dir()`
  * Feature: Check python package Makefile template
  * Feature: Makefile dependency on vignette source in python packages
  * Bug: Updated root Makefile template for notes projects
  * Feature: Install local python packages on local machines
  * Feature: Language is no longer used by venv. Instead, just look at config for python dep
  * Bug: Local Python packages requires full path to install
  * Feature: Install local packages
  * Internal: Simplify extracting logical values from config
  * Bug: detect lintr in config file
  * Internal: Allow `provision_venv()` to create `virtualenv` in places other
    than just the `notes/` directory
   
