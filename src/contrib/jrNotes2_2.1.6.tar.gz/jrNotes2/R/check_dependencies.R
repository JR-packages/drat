check_dependencies = function() {
  msg_start("Checking system dependenices...check_dependencies()")
  # Semi-cache previous result.
  if (!is.null(.jrnotes2$missing_deps) && .jrnotes2$missing_deps == 0) return(invisible(NULL))
  .jrnotes2$missing_deps = 0
  check_sys_deps()
  check_pip_deps()

  if (.jrnotes2$missing_deps > 0) stop("Dependencies missing.")
  msg_success("All necessary system dependencies are installed")
}

get_py_dependencies = function() {

  if (is.null(get_config()$python_pkgs)) return(NULL)

  # System packages required for courses with a python dependency
  c("python3",
    "python3-pip",
    "python3-venv",
    "python3-dev")
}

check_sys_deps = function() {
  # System packages required by every course
  sys_deps = c("texlive-latex-base",
               "texlive-fonts-extra",
               "texlive-xetex",
               "latexmk",
               "texinfo",
               "pandoc",
               "pandoc-citeproc",
               "git",
               "wget")

  # Append course specific system dependencies
  sys_deps = c(sys_deps, get_config()$deb_pkgs, get_py_dependencies())

  # List currently installed system packages
  apt_list = system2("apt",
                     args = c("list", "--installed"),
                     stdout = TRUE,
                     stderr = FALSE)

  is_installed = purrr::map_lgl(sys_deps,
                                ~any(stringr::str_starts(string = apt_list, pattern = .x)))
  missing_deps = sys_deps[!is_installed]

  .jrnotes2$missing_deps = .jrnotes2$missing_deps + length(missing_deps)
  if (length(missing_deps) > 0) {
    missing_deps = paste(missing_deps, collapse = " ")
    msg = glue::glue("An install of {missing_deps} is required for these notes.
                      Try running
                           sudo apt update &&
                           sudo apt install {missing_deps}")
    msg_error(msg, padding = TRUE)
  }
  return(invisible(sys_deps[!is_installed]))
}

check_pip_deps = function() {
  if (is.null(get_config()$python_pkgs)) return(NULL)

  pip_deps = c("virtualenv",
               "poetry",
               "Pygments")

  pip_installs = system2("pip", "freeze",
                         stdout = TRUE,
                         stderr = FALSE)

  is_installed = purrr::map_lgl(pip_deps,
                                ~any(stringr::str_starts(string = pip_installs, pattern = .x)))
  missing_pips = pip_deps[!is_installed]

  # Update dep count
  .jrnotes2$missing_deps = .jrnotes2$missing_deps + length(missing_pips)

  if (length(missing_pips) > 0) {
    missing_pips = paste(missing_pips, collapse = " ")
    msg = glue::glue("An install of {missing_pips} is required for these notes.
                        Try running
                          python3 -m pip install {missing_pips}", )
    msg_error(msg, padding = TRUE)
  }
  return(invisible(pip_deps[!is_installed]))
}
