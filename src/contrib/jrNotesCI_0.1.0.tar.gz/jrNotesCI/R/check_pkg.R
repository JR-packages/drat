check_pkg = function(dir = ".", ...) {
  op = setwd(dir)
  on.exit(setwd(op))
  inteRgrate::check_all(...)
}

#' Check the pkgs directory
#'
#' Runs inteRgrate::check_all() on all R packages found in pkgs/
#' @export
check_pkgs = function() {
  cli::cli_h2("Checking R packages...check_pkgs()")

  ## No package state
  if (!file.exists("pkgs")) {
    cli::cli_alert_info("No pkgs found")
    return(invisible(NULL))
  }
  op = setwd("pkgs")
  on.exit(setwd(op))
  ## Single pkg state
  if (file.exists("DESCRIPTION")) {
    cli::cli_alert_info("A single package found...checking")
    check_pkg(tag = FALSE, version = FALSE)
    return(invisible(NULL))
  }

  ## Multiple pkgs
  dirs = list.files(full.names = TRUE)
  cli::cli_alert_info("Found {length(dirs)} pkgs...checking")
  sapply(dirs, function(i) check_pkg(tag = FALSE, version = FALSE))
  return(invisible(NULL))
}
