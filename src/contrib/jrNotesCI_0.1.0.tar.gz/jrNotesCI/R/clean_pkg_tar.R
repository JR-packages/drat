#' Clean the pkgs from the cache directory
#'
#' Simple cleaning function
#' @export
clean_pkg_tar = function() {
  if (!file.exists("ci_pkg_tar") || !file.exists("pkgs")) return(invisible(NULL))
  tars = list.files("ci_pkg_tar", full.names = TRUE)
  if (length(tars) > 0) {
    to_delete = tars[!grepl("jrNotesCI", tars)]
    cli::cli_alert("Deleting {to_delete}")
    file.remove(to_delete)
  }
  return(invisible(NULL))
}
