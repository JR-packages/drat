#' @rdname apt_update
#' @export
r_install = function(update = TRUE) {
  cli::cli_h2("Installing R packages")
  if (isTRUE(update)) {
    remotes::update_packages()
  }

  dirs = list.files("r_pkgs", full.names = TRUE)
  cli::cli_alert_info("Found {length(dirs)} in r_pkgs...installing")
  sapply(dirs, function(i) remotes::install_local(i))

  r_pkgs = yaml::read_yaml("config.yml")$r_packages
  if (is.null(r_pkgs)) {
    cli::cli_alert_info("No R pkgs found")
  }
  # Ignores NULLS
  remotes::install_cran(r_pkgs)
  return(invisible(r_pkgs))
}
