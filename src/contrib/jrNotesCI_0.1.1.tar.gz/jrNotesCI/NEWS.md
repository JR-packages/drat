# jrNotesCI 0.1.1 _2020-12-30_
  * Bug

# jrNotesCI 0.1.0 _2020-12-22_
  * Initialise
