get_root_dir = function(dir = ".") {
  if (file.exists("config.yml")) {
    return(normalizePath(dir))
  }
  get_root_dir(dir = file.path("..", dir))
}
