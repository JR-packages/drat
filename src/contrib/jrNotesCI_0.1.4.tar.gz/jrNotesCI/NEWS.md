# jrNotesCI 0.1.4 _2021-01-09_
  * Bug: `get_root_dir()`

# jrNotesCI 0.1.3 _2021-01-08_
  * Feat: Install local python packages in the CI

# jrNotesCI 0.1.2 _2021-01-05_
  * Feat: check package versions

# jrNotesCI 0.1.1 _2020-12-30_
  * Bug

# jrNotesCI 0.1.0 _2020-12-22_
  * Initialise
