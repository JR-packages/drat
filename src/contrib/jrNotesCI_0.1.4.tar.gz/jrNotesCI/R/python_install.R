# python_install_local = function(dir) {
#   # think this will actually have to come in jrNotes2 rather than CI
# }

python_poetry_build_one = function(dir) {
  cli::cli_alert_info("Building {dir}")
  wd = setwd(dir)
  on.exit(setwd(wd))

  system2("/bin/bash", args = c("-c", shQuote("make build")))
  target_loc = file.path(get_root_dir(), "ci_python_pkgs")
  dir.create(target_loc, showWarnings = FALSE)
  src_tar = list.files("dist", pattern = "\\.tar\\.gz$", full.names = TRUE)
  file.copy(src_tar, target_loc)
  file.remove(src_tar)
  return(invisible(target_loc))
}

#' @rdname apt_update
#' @export
python_install = function() {
  cli::cli_h2("Building local Python packages")
  root = get_root_dir()
  con = yaml::read_yaml(file.path(root, "config.yml"))
  if (is.null(con$python_pkgs)) {
    cli::cli_alert_info("No python packages specified in config")
    return(invisible(NULL))
  }

  python_pkgs = file.path(root, "python_pkgs")
  if (!dir.exists(python_pkgs)) {
    cli::cli_alert_info("No python pkg source found")
    return(invisible(NULL))
  }

  pkgs = list.dirs(python_pkgs, recursive = FALSE)
  sapply(pkgs, python_poetry_build_one)

  return(invisible(NULL))
}
