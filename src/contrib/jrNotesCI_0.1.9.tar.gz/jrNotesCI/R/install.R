#' @rdname apt_update
#' @export
install = function(update = TRUE) {
  apt_install(update = update)
  r_install(update = update)
}
