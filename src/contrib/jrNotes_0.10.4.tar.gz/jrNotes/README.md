# jrNotes 
<!-- badges: start -->
[![Build Status](https://api.travis-ci.org/jr-packages/jrNotes.png?branch=master)](https://travis-ci.org/jr-packages/)
[![Codecov test coverage](https://codecov.io/gh/jr-packages/jrNotes/branch/master/graph/badge.svg)](https://codecov.io/gh/jr-packages/jrNotes?branch=master)
<!-- badges: end -->
---

Package for Jumping Rivers Notes

