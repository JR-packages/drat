
info = cli::symbol$info
tick = cli::symbol$tick
cross = cli::symbol$cross
circle_filled = cli::symbol$circle_filled
star = cli::symbol$star
