#' @import glue
#' @importFrom namer name_chunks
#' @importFrom config get
#' @importFrom jrPresentation add_border
NULL

info = clisymbols::symbol$info
tick = clisymbols::symbol$tick
cross = clisymbols::symbol$cross
circle_filled = clisymbols::symbol$circle_filled
