.jrnotes = new.env()
.jrnotes$error = FALSE
.jrnotes$error_funs = NULL
