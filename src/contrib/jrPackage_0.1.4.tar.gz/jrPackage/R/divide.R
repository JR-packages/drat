#' A function for dividing
#' 
#' A very useful function, that is excellent at dividing numbers
#' @param x a number
#' @param y another number
#' @export
div = function(x, y) x / y
