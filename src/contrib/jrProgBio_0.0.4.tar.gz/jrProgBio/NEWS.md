# jrProgBio 0.0.4 _2021-01-01_

  * Initialise
