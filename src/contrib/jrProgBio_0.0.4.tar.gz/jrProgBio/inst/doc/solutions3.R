## ----echo=FALSE---------------------------------
library(tufte)
# knitr::opts_chunk$set(results = "hide", echo = FALSE

## ---- echo=TRUE---------------------------------
sequence = function(n = 10, type = "dna") {
  if (type == "dna") {
    bases = c("C", "G", "A", "T")
  }
  paste(sample(bases, n, TRUE), collapse = "")
}

## -----------------------------------------------
sequence = function(n = 10, type = "dna") {
  if (type == "dna") {
    bases = c("C", "G", "A", "T")
  }
  if (type == "rna") {
    bases = c("C", "G", "A", "U")
  }
  paste(sample(bases, n, TRUE), collapse = "")
}

## ---- echo = TRUE, message = TRUE---------------
x = 5
message("The value of x is ", x)

## -----------------------------------------------
sequence = function(n = 10, type = "dna") {
  message("Creating ", type, " sequence")
  if (type == "dna") {
    bases = c("C", "G", "A", "T")
  }
  if (type == "rna") {
    bases = c("C", "G", "A", "U")
  }
  paste(sample(bases, n, TRUE), collapse = "")
}

## ---- echo=TRUE---------------------------------
library(stringr)
codons = function(sequence, offset = 0, length = 3) {
  start = seq(1 + offset, nchar(sequence), by = length)
  end = start + length - 1
  str_sub(sequence, start, end)
}

## -----------------------------------------------
codons = function(sequence, offset = 0, length = 3, reverse = FALSE) {
  if (reverse) sequence = stringi::stri_reverse(sequence)
  start = seq(1 + offset, nchar(sequence), by = length)
  end = start + length - 1
  str_sub(sequence, start, end)
}

s = sequence()
s
codons(s)
codons(s, reverse = TRUE)

## ---- echo=TRUE---------------------------------
# create a sequence
s = sequence(1000, type = "rna")
c = codons(s)

# the mapping between codon and amino acid
translation = c("AAA" = "Asn", "AAG" = "Asn",
                "UGG" = "Cys", "UGA" = "Cys")

# split it into pieces
s_split = str_split(s, "")

# collect the amino acid sequence using a loop
aa = character(length(c))
for (i in seq_along(aa)) {
  codon = c[i]
  aa[i] = translation[codon]
}

## -----------------------------------------------
translate = function(codons) {
  translation = c("AAA" = "Asn", "AAG" = "Asn",
                  "UGG" = "Cys", "UGA" = "Cys")
  s_split = str_split(s, "")
  aa = character(length(codons))
  for (i in seq_along(aa)) {
    codon = c[i]
    aa[i] = translation[codon]
  }
  return(aa)
}

## -----------------------------------------------
translate = function(codons) {
  translation = c("AAA" = "Asn", "AAG" = "Asn",
                  "UGG" = "Cys", "UGA" = "Cys")
  s_split = str_split(s, "")
  aa = character(length(codons))
  misses = 0
  for (i in seq_along(aa)) {
    codon = c[i]
    aa[i] = translation[codon]
    if (is.na(aa[i])) missses = misses + 1
  }
  message(misses, " codons could not be translated.")
  return(aa)
}

## ----eval=FALSE, echo=TRUE----------------------
#  vignette("solutions3", package = "jrProgBio")

