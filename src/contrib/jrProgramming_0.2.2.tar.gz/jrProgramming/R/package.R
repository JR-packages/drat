#' R courses from Jumping RIvers
#'
#' Functions and datasets used in courses by Jumping Rivers.
#' @name jrProgramming-package
#' @aliases jrProgramming
#' @docType package
#' @keywords package
NULL
