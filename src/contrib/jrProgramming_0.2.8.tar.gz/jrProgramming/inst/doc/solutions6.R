## ----include = FALSE----------------------------
knitr::opts_chunk$set(results = "show", echo = TRUE)

## ---- echo=TRUE---------------------------------
sample(1:6, 1)

## ---- echo=TRUE---------------------------------
roll_two_dice = function() {
total = sample(1:6, 1) + sample(1:6, 1)
return(total)
}

## ---- echo=TRUE, tidy = FALSE-------------------
## This creates a vector of 40 values;
## All values are initially zero
landings = numeric(40)

## ---- echo=TRUE---------------------------------
landings[2] = landings[2] + 1

## ---- echo=TRUE---------------------------------
simulate_monopoly = function(no_of_rolls) {
  landings = numeric(40)
  ## Start at GO
  current = 1
  for (i in 1:no_of_rolls) {
    current = current + roll_two_dice()
    if (current > 40) {
      current = current - 40
    }
    landings[current] = landings[current] + 1
  }
  return(landings)
}
no_of_rolls = 50000

## ---- echo=TRUE---------------------------------
sim = simulate_monopoly(no_of_rolls)

## ---- echo=FALSE--------------------------------
# no_of_rolls = 2000000
# sim1 = SimulateMonopoly(no_of_rolls)
# saveRDS(sim1, file="vignettes/sim1.RData")
sim = readRDS("sim1.RData")

## ---- echo=TRUE, fig.keep='all', fig.margin=TRUE, fig.cap="Probability of landing on a Monopoly square.", tidy = FALSE----
library("ggplot2")
library("tibble")
monopoly = tibble(index = seq_along(sim), sim = sim / sum(sim))
ggplot(monopoly) +
  geom_line(aes(x = index, y = sim)) +
  ylim(0, 0.06) +
  labs(x = "Square", y = "Probability")

## ---- echo=TRUE---------------------------------
community_chest = function(current) {
  goto = current
  u = runif(1)
  if (u < 1 / 16) {
    goto = 1 #Move to Go
  } else if (u < 2 / 16) {
    goto = 11 #Go To Jail :(
  }
  return(goto)
}

## ---- echo=TRUE---------------------------------
simulate_monopoly = function(no_of_rolls) {
  landings = numeric(40)
  ## Start at GO
  current = 1
  for (i in 1:no_of_rolls) {
    current = current + roll_two_dice()
    if (current > 40) {
      current = current - 40
    }
    landings[current] = landings[current] + 1
    if (current == 3) {
      cc_move = community_chest(current)
      if (cc_move != current) {
        current = cc_move
        landings[current] = landings[current] + 1
      }
    }
  }
  return(landings)
}

## ---- echo=TRUE---------------------------------
sim2 = simulate_monopoly(no_of_rolls)

## ---- echo=FALSE--------------------------------
# no_of_rolls = 2000000
# sim2 = SimulateMonopoly(no_of_rolls)
# saveRDS(sim2, file="vignettes/sim2.RData")
sim2 = readRDS("sim2.RData")

## ---- echo=TRUE, fig.keep='all', fig.margin=TRUE, fig.cap="Probability of landing on Monopoly square with the first community chest card implemented. Incorporating a single cummunity chest card has very little effect. For this graphic, I used 2 million simulations!", tidy = FALSE----
monopoly2 = tibble(index = seq_along(sim2),
                   sim = sim2 / sum(sim2))
ggplot(monopoly2) + 
  geom_line(aes(x = index, y = sim)) + 
  ylim(0, 0.06) +
  labs(x = "Square", y = "Probability")

## -----------------------------------------------
##Helper function to avoid code replication
check_state = function(current) {
  if (current > 40) {
    current = current - 40
  } else if (current < 1) {
    current = current + 40
  }
  return(current)
}

update_state_vector = function(current, move, landings) {
  if (move != current) {
    landings[current] = landings[current] + 1
  }
  return(landings)
}

## -----------------------------------------------
roll_two_dice_with_doubles = function(current) {
  df = data.frame(d1 = sample(1:6, 3, replace = TRUE),
                  d2 = sample(1:6, 3, replace = TRUE))
  df$total = apply(df, 1, sum)
  df$is_double = df$d1 == df$d2
  if (df$is_Double[1] & df$is_double[2] & df$is_double[3]) {
    current = 11#Go To Jail
  } else if (df$is_double[1] & df$is_double[2]) {
    current = current + sum(df$total[1:2])
  } else {
    current = current + df$total[1]
  }
  return(current)
}

## -----------------------------------------------
# Answers for community chest and chance questions
community_chest = function(current) {
  u = runif(1)
  goto = current #Default. Do nothing
  if (u < 1 / 16) {
    goto = 1 #Go
  } else if (u < 2 / 16) {
    goto = 11 #Jail
  } else if (u < 3 / 16) {
    goto = 2 #Old Kent Rd
  } else if (u < 4 / 16) {
    goto = chance(current)
  }
  return(goto)
}

chance = function(current) {
  u = runif(1)
  goto = current #Default. Do nothing
  if (u < 1 / 16) {
    goto = 1 # Go
  } else if (u < 2 / 16) {
    goto = 25 #Tra Square
  } else if (u < 3 / 16) {
    goto = 12 #Pall Mall
  } else if (u < 4 / 16) {
    goto = 11 #Jail
  } else if (u < 5 / 16) {
    goto = 16 #Mary' Stat
  } else if (u < 6 / 16) {
    goto = 40 #Mayfair
  } else if (u < 7 / 16) {
    goto = check_state(current - 3) #Must check, since goto maybe negative!
  } else if (u < 8 / 16) {
    if (current > 29
        | current < 13) {
      goto = 13
    } else {
      goto = 29
    }
  }
  return(goto)
}

## -----------------------------------------------
simulate_monopoly = function(no_of_turns) {
  landings = numeric(40)
  ##Start GO
  current = 1
  for (i in 1:no_of_turns) {
    current = roll_two_dice_with_doubles(current)
    current = check_state(current)
    landings = update_state_vector(current, -1, landings)
    if (current == 8 | current == 23 | current == 37) {
      #Chance
      move = chance(current)
      landings = update_state_vector(move, current, landings)
      current = move
    }
    if (current == 3 | current == 18 | current == 34) {
      #Community Chest
      move = community_chest(current)
      landings = update_state_vector(move, current, landings)
      current = move
    }
    ##Go To Jail. Chance could also send you here by
    ##going back three places
    if (current == 31) {
      current = 11
      landings = update_state_vector(current, -1, landings)
    }
  }
  return(landings)
}

## ---- fig.cap="Distribution of resting places in a game of monopoly using 50,000 rolls", echo = FALSE, out.width="0.8\\textwidth", out.height="60%", fig.pos="!h", fig.align='center'----
knitr::include_graphics("example_distribution.png")

## ---- eval=FALSE, echo=TRUE---------------------
#  vignette("solutions6", package = "jrProgramming")

