# jrRSConnect 0.0.4 _2020-11-16_
  * Bug: Remove erroneous vertical spacing after Rmd example

# jrRSConnect 0.0.3 _2020-10-29_
  * Internal: Pass InteRgrate checks
