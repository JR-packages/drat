#' Extract the questionnaire link
#'
#' Extract the questionnaire link from a file
#' @param fname Default \code{feedback_link.txt}
get_feedback_url = function(fname = "feedback_link.txt") {
  if (!file.exists(fname)) {
    stop("File does not exist", call. = FALSE)
  }
  scan(fname, what = character())
}
