#' @rdname sc_background_logo
#' @export
sc_display_clients = function() {
  clients = c("shell.png", "sustrans.png",  "yorkshire.png",
              "hastings.png", "pragmatic.png", "nhs.png",
              "royal-statistical-society.jpg", "francis-crick.png",
              "ministry-of-defence.png", "university-of-manchester.png")
  # Create destination in user area
  to = "assets/client-logos"
  dir.create(to, recursive = TRUE, showWarnings = FALSE)

  paths = file.path(to, clients)
  pkg_loc = system.file(package = "jrSlides")
  file.copy(file.path(pkg_loc, paths), to)

  # Create HTML snippet
  txt = glue('<img src="{to}/{clients}"></img>')
  txt = glue_collapse(txt)
  glue::glue('<div id="clients">{txt}</div>')
}

#' Short cut functions
#'
#' Functions for providing handy slide shortcuts.
#' @export
sc_background_logo = function() {
  styler(layout = TRUE,
         border = "inverse",
         background_image = "assets/title-jr-white-logo.png",
         background_size = "contain",
         inverse = TRUE,
         hor_align = "middle",
         ver_align = "middle")
}
