# jrSpatial 0.2.2 _2020-09-22_
  * Add NEWS.md
  * Change pkg title
  * Allowing 2 extra notes (UTF-8 string and all declared imports)
