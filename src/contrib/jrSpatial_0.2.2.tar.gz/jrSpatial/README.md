
## Package for the Jumping Rivers Spatial Course

[![Build
Status](https://api.travis-ci.org/jr-packages/jrSpatial.png?branch=master)](https://travis-ci.org/jr-packages/jrSpatial)
