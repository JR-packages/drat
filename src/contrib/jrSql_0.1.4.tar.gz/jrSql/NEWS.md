# jrSql 0.1.4 _2021-01-04_

  * Initialise
