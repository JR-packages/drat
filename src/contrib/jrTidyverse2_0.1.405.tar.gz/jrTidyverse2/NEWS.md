# jrTidyverse2 0.1.405 _2020-07-15_
  * Addings news.md
  * Adding **stopwords** to imports
  * Getting package to pass inteRgrate checks
