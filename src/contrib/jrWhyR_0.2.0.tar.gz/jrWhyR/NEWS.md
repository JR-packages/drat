# jrWhyR 0.2.0 _2020-08-13_
  * Adding the material directory
