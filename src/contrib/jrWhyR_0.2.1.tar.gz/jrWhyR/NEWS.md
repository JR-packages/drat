# jrWhyR 0.2.1 _2020-12-07_
  * Change pkg title
  * Add libsodium-dev ubuntu install to `before_install` in travis.yml

# jrWhyR 0.2.0 _2020-08-13_
  * Adding the material directory
