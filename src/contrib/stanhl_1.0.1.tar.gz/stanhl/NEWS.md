# stanhl 1.0.1 _2020-10-24_
  * Internal: Remove {glue} as a dependency
  * Tidy up code

# stanhl 1.0.0 _2020-10-24_
  * Fix: add support for python3
  * Improvement: use `knit_hooks$set()` to apply styling to all stan chunks
  * Improvement: use `system2` instead of `system`
